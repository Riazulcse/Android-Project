# 2D Puzzle Sample
Sample project that's basically a 2D-puzzle with a Bejeweled-like swipe UI.

YouTube tutorial video: https://www.youtube.com/watch?v=YKbFx8PDTIo

![alt tag](https://media.giphy.com/media/l0Iy0B3etSoQusXeM/giphy.gif)
